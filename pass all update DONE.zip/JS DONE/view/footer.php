<style>
    footer {
  text-align: center;
  padding: 3px;
  background-color: lightgreen;
  color: white;
  margin-top: 20px;
}
</style>
<footer>
  <p>Coyright Claim 2022<br>
  <p> By Team Hexa</p>
</footer>