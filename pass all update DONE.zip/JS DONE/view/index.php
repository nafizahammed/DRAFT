<?php
header("location: registration.php");
?>