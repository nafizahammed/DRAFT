<html>
<body>
<head>
  <link rel="stylesheet" href="reg.css">
</head>
  <nav>
    
  <!-- <div class="topnav"> -->
  <img src="img2.png" style="width: 100px;height: 80px;">

  <ul>
  <li><a class="active" href="index.php"> Home</a></li>
  <li><a class="active" href="dashboard.php"> Dashboard</a></li>
  <li><a class="active" href="profile.php"> Profile</a></li>
  <li><a class="active" href="security.php"> Security</a></li>
  <li><a class="active" href="logout.php"> Logout</a></li>

</ul>
</nav>

</body>
</html>